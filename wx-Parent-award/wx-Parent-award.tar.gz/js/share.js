
$(function () {
    wxShare("share");
})
// $(".btn2").click=function(){
// $(".box .inner").click();
// }
function getFunc(){

}



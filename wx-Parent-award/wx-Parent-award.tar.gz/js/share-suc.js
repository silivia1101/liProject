/**
 * Created by LE on 2017/10/24.
 */
$(".btn3").click(function(){
    // window.location.href="shareSuc.html";
    window.location.href="http://wx-parent-web.leo1v1.com/wx-Parent-award/shareSuc.html";
})

$(function () {
    wxShare();
})

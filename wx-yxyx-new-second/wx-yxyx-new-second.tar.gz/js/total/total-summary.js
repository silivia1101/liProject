/**
 * Created by LE on 2017/10/21.
 */

function clickFunc(index){
    switch(index){
        case 1:
            window.location.href="total-summary-total.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-total.html";
            break;
        case 11:
            window.location.href="total-summary-total-invite.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-total-invite.html";
            break;
        case 12:
            window.location.href="total-summary-total-cash.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-total-cash.html";
            break;
        case 13:
            window.location.href="total-summary-total-activity.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-total-activity.html";
            break;
        case 2:
            window.location.href="total-summary-available.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-available.html";
            break;
        case 21:
            window.location.href="total-summary-available-invite.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-available-invite.html";
            break;
        case 22:
            window.location.href="total-summary-available-cash.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-available-cash.html";
            break;
        case 23:
            window.location.href="total-summary-available-activity.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-available-activity.html";
            break;
        case 3:
            window.location.href="total-summary-already.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-already.html";
            break;
        case 4:
            window.location.href="total-summary-cash.html";
            // window.location.href="http://wx-yxyx-web.leo1v1.com/wx-yxyx-new-second/total-summary-cash.html";
            break;
        case 5:
            window.location.href="total-summary-select.html";
            break;
        case 51:
            window.location.href="total-summary-select-bank.html";
            break;
        case 52:
            window.location.href="total-summary-select-net.html";
            break;
        default:
            break;
    }
}